/*
 * usart.h
 *
 *  Created on: Nov 15, 2011
 *      Author: MMM
 */
#include "STM32f10x.h"
#include <stdio.h>
#ifndef USART_H_
#define USART_H_

void USART1Init(void);
void USART2Init(void);

#endif /* USART_H_ */
